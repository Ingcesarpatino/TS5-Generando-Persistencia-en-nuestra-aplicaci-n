package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.Context;

import java.util.ArrayList;

public class RecyclerViewProfileFragmentPresenter implements IRecyclerViewFragmentPresenter{

    private IRecyclerViewProfileFragmentView iRecyclerViewProfileFragmentView;
    private Context context;
    private FotosConst constructorFotos;
    private ArrayList<Foto> fotos;

    public RecyclerViewProfileFragmentPresenter (IRecyclerViewProfileFragmentView iRecyclerViewProfileFragmentView, Context context){
        this.iRecyclerViewProfileFragmentView = iRecyclerViewProfileFragmentView;
        this.context = context;
        obtenerItems();
    }

    @Override
    public void obtenerItems() {
        constructorFotos = new FotosConst(context);
        fotos = constructorFotos.obtenerDatosIniciales();
        mostrarItemsRV();
    }

    @Override
    public void mostrarItemsRV() {
        iRecyclerViewProfileFragmentView.inicilizarAdaptadorRV(iRecyclerViewProfileFragmentView.crearAdaptador(fotos));
        iRecyclerViewProfileFragmentView.generarLayout();
    }
}
