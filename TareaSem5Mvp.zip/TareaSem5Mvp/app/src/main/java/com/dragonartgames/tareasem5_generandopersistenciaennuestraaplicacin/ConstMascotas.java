package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.ContentValues;
import android.content.Context;

import java.util.ArrayList;

public class ConstMascotas {
    private static final int LIKE = 1;
    private Context context;

    public ConstMascotas(Context context){
        this.context=context;
    }

    public ArrayList<Mascota> obtenerDatosIniciales(){
        ArrayList<Mascota>  mascotas = new ArrayList<Mascota>();
        mascotas.add(creaMascota(R.drawable.perro1,"BRUNO",'M',551));
        mascotas.add(creaMascota(R.drawable.gato2,"LUNA",'H',552));
        mascotas.add(creaMascota(R.drawable.perro3,"RUFO",'M',553));
        mascotas.add(creaMascota(R.drawable.perro4, "MAXIMUS",'M',554));
        mascotas.add(creaMascota(R.drawable.gat05,"KIRA",'H',555));
        mascotas.add(creaMascota(R.drawable.gato2,"FELIX",'M',556));
        mascotas.add(creaMascota(R.drawable.perro1,"KATTY",'H',557));
        mascotas.add(creaMascota(R.drawable.gat05,"Rocky",'M',558));
        mascotas.add(creaMascota(R.drawable.perro4,"SASHA",'H',559));

        return mascotas;
    }

    public Mascota creaMascota(int foto, String nombre, char genero, int id){
        BDpetapp db = new BDpetapp(context);
        Mascota mascotabd = db.obtenerMascotaPorNombre(nombre);
        if(mascotabd.getId()==0)
            return new Mascota(foto,nombre,genero,id);
        else
            return mascotabd;
    }

    public ArrayList<Mascota> obtenerMascotasFavoritasDummy(){
        ArrayList<Mascota>  mascotas = new ArrayList<Mascota>();

        mascotas.add(new Mascota(R.drawable.perro1,"BRUNO",'H',4,1));
        mascotas.add(new Mascota(R.drawable.gat05,"LUNA",'M',3,2));
        mascotas.add(new Mascota(R.drawable.perro4,"RUFO",'M',5,3));
        mascotas.add(new Mascota(R.drawable.gato2,"KIRA",'H',4,4));
        mascotas.add(new Mascota(R.drawable.perro3,"MAXIMUS",'M',2,5));

        return mascotas;
    }

    public ArrayList<Mascota> obtenerMascotasFavoritas(){
        BDpetapp db = new BDpetapp(context);
        return db.obtenerTodasLasMascotas();
    }

    public long insertarMascota(String nombre, String genero, int foto, int rate){
        BDpetapp db = new BDpetapp(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(BDConstant.TABLE_MASCOTA_NOMBRE,nombre);
        contentValues.put(BDConstant.TABLE_MASCOTA_GENERO,genero);
        contentValues.put(BDConstant.TABLE_MASCOTA_FOTO,foto);
        contentValues.put(BDConstant.TABLE_MASCOTA_RATE,rate);

        long id = db.insertarMascota(contentValues);
        return id;
    }

    public long insertMascota(String nombre, String genero, int foto, int rate){
        BDpetapp db = new BDpetapp(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(BDConstant.TABLE_MASCOTA_NOMBRE,nombre);
        contentValues.put(BDConstant.TABLE_MASCOTA_GENERO,genero);
        contentValues.put(BDConstant.TABLE_MASCOTA_FOTO,foto);
        contentValues.put(BDConstant.TABLE_MASCOTA_RATE,rate);
        return db.insertMascota(contentValues);
    }


    public void darLikeMascota(Mascota mascota){
        BDpetapp db = new BDpetapp(context);
        int likes = obtenerLikesMascota(mascota) + LIKE;
        ContentValues contentValues = new ContentValues();
        contentValues.put(BDConstant.TABLE_MASCOTA_RATE,likes);
        String whereClause= BDConstant.TABLE_MASCOTA_ID+" = "+mascota.getId();
        db.insertarLikeMascota(contentValues,whereClause);
    }

    public int obtenerLikesMascota(Mascota mascota){
        BDpetapp db = new BDpetapp(context);
        return db.obtenerLikesMascota(mascota.getId());
    }
}
