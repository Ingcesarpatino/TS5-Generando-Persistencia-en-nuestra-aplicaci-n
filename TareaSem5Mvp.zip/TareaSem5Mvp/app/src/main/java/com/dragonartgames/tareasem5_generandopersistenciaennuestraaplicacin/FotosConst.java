package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.Context;

import java.util.ArrayList;

public class FotosConst {

    private Context context;

    public FotosConst(Context context){
        this.context=context;
    }

    public ArrayList<Foto> obtenerDatosIniciales(){
        ArrayList<Foto> fotos = new ArrayList<Foto>();

        fotos.add(new Foto(R.drawable.perro1,3));
        fotos.add(new Foto(R.drawable.perro1,5));
        fotos.add(new Foto(R.drawable.perro1,8));
        fotos.add(new Foto(R.drawable.perro1,2));
        fotos.add(new Foto(R.drawable.perro1,1));
        fotos.add(new Foto(R.drawable.perro1,9));
        fotos.add(new Foto(R.drawable.perro1,4));
        fotos.add(new Foto(R.drawable.perro1,9));
        fotos.add(new Foto(R.drawable.perro1,6));

        return fotos;
    }
}
