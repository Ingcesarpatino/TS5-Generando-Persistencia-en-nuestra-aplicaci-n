package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.Context;

import java.util.ArrayList;

public class RecyclerViewMisFavoritasPresenter  implements IRecyclerViewFragmentPresenter{

    private IRecyclerViewMascotaFavView iRecyclerViewMascotaFavView;
    private Context context;
    private ConstMascotas constMascotas;
    private ArrayList<Mascota> mascotas;

    public RecyclerViewMisFavoritasPresenter (IRecyclerViewMascotaFavView iRecyclerViewMascotaFavView, Context context){
        this.iRecyclerViewMascotaFavView = iRecyclerViewMascotaFavView;
        this.context = context;
        obtenerItems();
    }

    @Override
    public void obtenerItems() {
        constMascotas = new ConstMascotas(context);
        mascotas = constMascotas.obtenerMascotasFavoritas(); //datos de la base de datos
        //mascotas = constructorMascotas.obtenerMascotasFavoritasDummy(); //datos de un ArrayList
        mostrarItemsRV();
    }

    @Override
    public void mostrarItemsRV() {
        iRecyclerViewMascotaFavView.inicilizarAdaptadorRV(iRecyclerViewMascotaFavView.crearAdaptador((mascotas)));
        iRecyclerViewMascotaFavView.generarLayout();
    }
}
