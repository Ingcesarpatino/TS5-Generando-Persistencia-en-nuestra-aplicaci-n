package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import java.util.ArrayList;

public interface IRecyclerViewFragmentView {

    /*Se declara más general para que pueda ser lineal (vertical u horizontal) o grid*/
    public void generarLayout();

    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);

    public void inicilizarAdaptadorRV(MascotaAdaptador adaptador);
}
