package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        setUpViewPager();

        if (toolbar != null){
            setSupportActionBar(toolbar);
        }

        getSupportActionBar().setIcon(R.drawable.oso);

        agregarFABcamara();
    }

    @Override
    //Infla el recurso menú en la vista
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones,menu);
        return true;
    }

    //Para controlar las opciones del menu
    //El metodo recibe el item del menu seleccionado
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.mAbout:
                Intent intent1 = new Intent(this, Conocenos.class);
                startActivity(intent1);
                break;

            case R.id.mSettings:
                Intent intent2 = new Intent(this, Contact0.class);
                startActivity(intent2);
                break;

            case R.id.m5Fav:
                Intent intent3 = new Intent(this, MisFavoritas.class);
                startActivity(intent3);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(new RecyclerViewFragment());
        fragments.add(new FragmentPerfil());

        return fragments;
    }

    //pone en orbita los framents
    private void setUpViewPager(){

        viewPager.setAdapter(new PAdaptador(getSupportFragmentManager(),agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.mascotas);
        tabLayout.getTabAt(1).setIcon(R.drawable.perrocara);

    }

    public void agregarFABcamara(){
        FloatingActionButton fabCamara = (FloatingActionButton) findViewById(R.id.fabCamera);
        fabCamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(), getResources().getString(R.string.msg_clickcam), Toast.LENGTH_SHORT).show();
            }
        });
    }

}