package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.content.Context;

import java.util.ArrayList;

public interface IRecyclerViewFragmentPresenter {

    public void obtenerItems();

    public void mostrarItemsRV();

    class RecyclerViewFragmentPresenter implements IRecyclerViewFragmentPresenter{

        private IRecyclerViewFragmentView iRecyclerViewFragmentView;
        private Context context;
        private ConstMascotas constMascotas;
        private ArrayList<Mascota> mascotas;

        public RecyclerViewFragmentPresenter (IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context){
            this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
            this.context = context;
            obtenerItems();
        }

        @Override
        public void obtenerItems() {
            constMascotas = new ConstMascotas(context);
            mascotas = constMascotas.obtenerDatosIniciales(); //datos de un ArrayList
            mostrarItemsRV();
        }

        @Override
        public void mostrarItemsRV() {
            iRecyclerViewFragmentView.inicilizarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador((mascotas)));
            iRecyclerViewFragmentView.generarLayout();
        }
    }
}
