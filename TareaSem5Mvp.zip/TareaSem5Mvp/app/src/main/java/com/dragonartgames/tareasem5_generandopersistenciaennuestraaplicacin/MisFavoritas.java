package com.dragonartgames.tareasem5_generandopersistenciaennuestraaplicacin;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MisFavoritas extends AppCompatActivity implements IRecyclerViewMascotaFavView {

    private ArrayList<Mascota> mascotas;
    private RecyclerView rvMascotas;
    private IRecyclerViewFragmentPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_favoritas);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.actionBarFav);
        setSupportActionBar(miActionBar);


        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();
        // Habilita el botón Subir
        ab.setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setIcon(R.drawable.oso);

        rvMascotas = (RecyclerView) findViewById(R.id.rvFavoritas);
        presenter = new RecyclerViewMisFavoritasPresenter(this,this);
    }


    @Override
    public void generarLayout() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(llm);
    }

    @Override
    public MascotaFavAdapter crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaFavAdapter adaptador = new MascotaFavAdapter(mascotas,this);
        return adaptador;
    }

    @Override
    public void inicilizarAdaptadorRV(MascotaFavAdapter adaptador) {
        rvMascotas.setAdapter(adaptador);
    }
}